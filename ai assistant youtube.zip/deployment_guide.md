# Deployment Guide for AI YouTube Assistant

## 1. Setup Virtual Environment
```bash
pkg install python -y
pkg install python-venv
python -m venv env
source env/bin/activate