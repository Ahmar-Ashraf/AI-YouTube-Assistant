import requests  

def post_to_tiktok(video_path):  
    print(f"Uploading {video_path} to TikTok...")  
    # API logic for TikTok integration (Placeholder)  

def post_to_instagram(video_path):  
    print(f"Uploading {video_path} to Instagram...")  
    # API logic for Instagram integration (Placeholder)  

video_file = "shorts.mp4"  
post_to_tiktok(video_file)  
post_to_instagram(video_file)